/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lucas.teste;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author lucas
 */
public class Calculadora {
    
    public static void main(String[] args) {              
         
         String titulo = "caluladora-java";
         double v1,v2,result = 0;
         double[] vetor = new double[4];       
         int op;
          
        System.err.println(titulo.toUpperCase() + "\n");

           Scanner scan = new Scanner(System.in);        
       
         System.out.println("----------------------------");
         System.out.println("| 1- efetuar Adição        |");
         System.out.println("| 2- efetuar Subtração     |");
         System.out.println("| 3- efetuar Divisão       |");
         System.out.println("| 4- efetuar Multiplicação |");
         System.out.println("----------------------------\n");
         
         System.out.println("Infome o número da opção: ");
         op = (int) scan.nextDouble();
            
         if(op < 5 && op > 0){
         System.out.println("Informe o primeiro número: ");
           v1 = scan.nextDouble();
             
           System.out.println();
             
         System.out.println("Informe o segundo número: ");             
           v2 = scan.nextDouble();
           
             DecimalFormat df = new DecimalFormat("0.##");
             
           switch(op){
               
               case 1:
                vetor[0] = result = v1 + v2;
                   break;
                   
               case 2:
                vetor[1] = result = v1 - v2;
                   break;
                
               case 3:
                vetor[2] = result = v1 / v2;
                   break;
                   
               case 4:
                vetor[3] = result = v1 * v2;
                   break;                         
           }           
            
           System.out.println("o resultado da operação efetuada é: " + df.format(result) + "\n");
             
            for(int i = 0; i < 1; i++){
                System.out.println("Outras Possibilidades.");
                System.err.println("-----------------------------");
                System.out.println("se fosse somado: " + df.format(vetor[i] = result = v1 + v2));
                System.out.println("se fosse subtraido: " + df.format(vetor[i] = result = v1 - v2));
                System.out.println("se fosse divido: " + df.format(vetor[i] = result = v1 / v2));
                System.out.println("se fosse multiplicado: " + df.format(vetor[i] = result = v1 * v2));
         } 
          
         }else{
             System.err.println("erro! Informe o número correto da posicão.");             
    }
  }    
}
