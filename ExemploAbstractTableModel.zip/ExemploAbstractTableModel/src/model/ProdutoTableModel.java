/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author lucas
 */
public class ProdutoTableModel extends AbstractTableModel{

     ArrayList<Produto> dados = new ArrayList<>();
     private String[] colunas = {"Nome","Quantidade","Valor"};

    @Override
    public String getColumnName(int column) {
        return colunas[column];//pega o nome de cada coluna
    }
     
    @Override
    public int getRowCount() {
        return dados.size();//retorna a o tamanho do array
    }

    @Override
    public int getColumnCount() {
        return colunas.length; //pega o tamanho da coluna
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
         
        if(coluna == 0){
             return dados.get(linha).getNome();
         
        }else if(coluna == 1){
             return dados.get(linha).getQuantidade();
        
        }else if(coluna == 2){
             return dados.get(linha).getValor();
         }
    
         return null;
    }

    @Override
    public void setValueAt(Object valor, int linha, int coluna) {
      
        switch(coluna){
            
            case 0:
                dados.get(linha).setNome((String) valor);
                break;
            case 1:
                dados.get(linha).setQuantidade(Integer.parseInt((String) valor));
                break;
            case 2:
                dados.get(linha).setValor(Double.parseDouble((String) valor));
                break;
        }
        this.fireTableRowsUpdated(linha, linha);
    }
    
    
    public void addRow(Produto p){
        dados.add(p);
       fireTableDataChanged();          
    }
    
    public void removeRow(int linha){
        dados.remove(linha);
        fireTableRowsDeleted(linha, linha);
    }
   
}