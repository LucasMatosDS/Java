/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.ClienteVO;
import persistencia.ConexaoBanco;

/**
 *
 * @author Lucas Matos
 * @since 09/06/2019
 * @version 1.0 beta
 */
public class ClienteDAO {
    
    
    //inicio metodo para inserir dados no BD
   public void cadastrarCliente(ClienteVO cVO) throws SQLException{
       
       Connection con = ConexaoBanco.getConexao();
   
       Statement stat = con.createStatement();
       
       try {
             String sql;
     
             sql = "insert into clientes(idCliente,nome,sobrenome,telefone)"+"values(null, '"+ cVO.getNome()+"', '"+cVO.getSobrenome()+"', "+cVO.getTelefone()+")";
           
          
           stat.execute(sql);
       } catch (SQLException e) {
           throw new SQLException("Erro ao inserir cliente!");
       }finally {
       con.close();
       stat.close();
       }
    }
  
 
   public ArrayList<ClienteVO> buscarCliente() throws SQLException{
           Connection con = ConexaoBanco.getConexao();
           Statement stat = con.createStatement();
           
           try {
           String sql;
           
           sql = "select * from clientes";
           
           ResultSet rs = stat.executeQuery(sql);
           
           ArrayList<ClienteVO> cli = new ArrayList<>();
           
          while(rs.next()) {
          ClienteVO c = new ClienteVO();
          
          c.setIdCliente((rs.getLong("idCliente")));
          c.setNome(rs.getString("nome"));
          c.setSobrenome(rs.getString("sobrenome"));
          c.setTelefone(rs.getInt("telefone"));
          
          cli.add(c);
          }
          return cli;
       } catch (SQLException e) {
           throw new SQLException("Erro ao buscar clientes! "+e.getMessage());
       }finally{
       con.close();
       stat.close();
       }
    }
    
}
