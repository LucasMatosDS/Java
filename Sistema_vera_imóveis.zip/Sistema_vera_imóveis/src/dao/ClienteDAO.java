/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.ClienteVO;
import persistence.ConexaoBanco;

/**
 *
 * @author lucas
 */
public class ClienteDAO {
 
    public void cadastrarCliente(ClienteVO cVO) throws SQLException{
   
       Connection con = ConexaoBanco.getConexao();
     
       Statement stat = con.createStatement();
       
       try {
       
           String sql,sql_reset;

           sql = "insert into visitas(id_visitante,data,nome,documento,h_entrada,h_saida,sala,observacao) values(null,'"+cVO.getData()+"','"+cVO.getNome()+"','"+cVO.getDoc()+"','"+cVO.getH_entrada()+"','"+cVO.getH_saida()+"','"+cVO.getSala()+"','"+cVO.getObservacao()+"')";
           
           stat.execute(sql);
           
       } catch (SQLException e) {
           throw new SQLException("Erro ao inserir cliente!");
       
       }finally {
           
       con.close();
       stat.close();
       
       }
    }
  
 
   public ArrayList<ClienteVO> buscarCliente() throws SQLException{
           Connection con = ConexaoBanco.getConexao();
           Statement stat = con.createStatement();
           
           try {
           String sql;
                  
           sql = "select * from visitas";
         
           ResultSet rs = stat.executeQuery(sql);                      
          
           ArrayList<ClienteVO> cl = new ArrayList<>();
           
          while(rs.next()) {
              
          ClienteVO c = new ClienteVO();
          
          c.setId_visitante((rs.getLong("id_visitante")));
          c.setData(rs.getString("data"));
          c.setNome(rs.getString("nome"));
          c.setDoc(rs.getString("documento"));
          c.setH_entrada(rs.getString("h_entrada"));
          c.setH_saida(rs.getString("h_saida"));
          c.setSala(rs.getInt("sala"));
          c.setObservacao(rs.getString("observacao"));
          
          cl.add(c);
          
          }
          
          return cl;
          
       } catch (SQLException e) {
           throw new SQLException("Erro ao buscar cliente! "+e.getMessage());
           
       }finally{
               
       con.close();
       stat.close();
       
       }
    }
   
     public void deletar(long id_visitante) throws SQLException {

        //Buscando uma conexão com o Banco de Dados
        Connection con = ConexaoBanco.getConexao();
        /*Criando obj. capaz de executar instruções
         SQL no banco de dados*/
        Statement stat = con.createStatement();

        try {
            String sql,sql_reset;
            
            sql = "delete from visitas where id_visitante=" + id_visitante;
            sql_reset = "alter table visitas auto_increment = 1";

            stat.execute(sql);
            stat.execute(sql_reset);
            
        } catch (SQLException se) {
            throw new SQLException("Erro ao deletar cliente! " + se.getMessage());
        } finally {
            stat.close();
            con.close();
        }
     }
     
      public void deletarTodosOsRegistros(String sala) throws SQLException {

        //Buscando uma conexão com o Banco de Dados
        Connection con = ConexaoBanco.getConexao();
        /*Criando obj. capaz de executar instruções
         SQL no banco de dados*/
        Statement stat = con.createStatement();

        try {
            
            String sql;
            
            sql = "delete from visitas where sala="+ sala;
            
            stat.execute(sql);
            
        } catch (SQLException se) {
            throw new SQLException("Erro ao deletar Registros! " + se.getMessage());
        } finally {
            stat.close();
            con.close();
        }
     }
   
    public void alterar(ClienteVO cVO) throws SQLException {

        Connection con = ConexaoBanco.getConexao();
        Statement stat = con.createStatement();

        try {
            
            String sql;    
   
                       sql = "update visitas set "
                    + "nome='" + cVO.getNome() + "', documento='" + cVO.getDoc() +"', h_entrada='"+cVO.getH_entrada()+"', h_saida='"+cVO.getH_saida()+"', sala="+cVO.getSala()+", observacao='"+cVO.getObservacao()+"'"
                    + "where id_visitante=" + cVO.getId_visitante()+ "";

            stat.executeUpdate(sql);

        } catch (SQLException se) {
            throw new SQLException("Erro ao alterar hora de saída\ndo cliente!"+ se.getMessage());
        } finally {
            con.close();
            stat.close();
      }
    }
    
     public ArrayList<ClienteVO> filtrar(String query) throws SQLException {
        
        Connection con = ConexaoBanco.getConexao();
        Statement stat = con.createStatement();
        
        try {
            
            String sql;
            sql = "select * from visitas " + query;

            ResultSet rs = stat.executeQuery(sql);
            
            ArrayList<ClienteVO> cli = new ArrayList<>();

            while (rs.next()) {
                ClienteVO cVO = new ClienteVO();
                cVO.setData(rs.getString("data"));
                cVO.setNome(rs.getString("nome"));
                cVO.setDoc(rs.getString("documento"));
                cVO.setH_entrada(rs.getString("h_entrada"));
                cVO.setH_saida(rs.getString("h_saida"));
                cVO.setSala(rs.getInt("sala"));
                cVO.setObservacao(rs.getString("observacao"));
                
                cli.add(cVO);
            }
            
            return cli;
            
        } catch (SQLException se) {
            throw new SQLException("Erro ao buscar clientes no Banco De Dados! " + se.getMessage());
        } finally {
            stat.close();
            con.close();
       }
     }    
}
