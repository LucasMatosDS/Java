/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author lucas
 */
public class CoresJTable implements TableCellRenderer{

  public static final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();
  int line;
  Object valor,sala,nome;
  
  @Override
  public  Component getTableCellRendererComponent(JTable table, Object value,
      boolean isSelected, boolean hasFocus, int row, int column) {
    Component renderer = DEFAULT_RENDERER.getTableCellRendererComponent(
        table, value, isSelected, hasFocus, row, column);
    ((JLabel) renderer).setOpaque(true);
        
    Color foreground  = null, background = null; 
          
   valor = table.getValueAt(row, 5);
   sala = table.getValueAt(row, 6);
   nome = table.getValueAt(row, 2);
   
  if(valor.equals("-")){
                foreground = new Color(204,0,0);
                background = new Color(252,233,3);
                table.setToolTipText("Registro Pendente");
   
  }else if(!nome.equals("Eduardo") && !nome.equals("Rose") && sala.equals("301") && valor.equals("-")){      
                foreground = new Color(255,255,255);
                background = new Color(64,64,255); 
                
   }else if(!nome.equals("Eduardo") && !nome.equals("Rose") && sala.equals("301")){         
                foreground = new Color(255,255,255);
                background = new Color(64,64,255);
   
   }else if(sala.equals("201") && !nome.equals("Darcy maurente") || !nome.equals("Diego maurente") && valor.equals("-")){
                foreground = new Color(255,255,255);
                background = new Color(16,107,33);
                
   
   }else if(sala.equals("201") && nome.equals("Darcy maurente") || nome.equals("Diego maurente")){
                foreground = new Color(255,255,255);
                background = new Color(73,182,117);
                
   }else if(sala.equals("303") || sala.equals("702") && !nome.equals("Silvia")){
                foreground = new Color(255,255,255);
                background = new Color(225,97,101);    
  
   }else if(sala.equals("303") || sala.equals("702") && nome.equals("Silvia")){
                foreground = new Color(255,255,255);
                background = new Color(188,143,143);    
   
   }else if(sala.equals("301")){
                foreground = new Color(255,255,255);
                background = new Color(139,185,221);
                
   }else if(sala.equals("401")){
                foreground = new Color(255,255,255);
                background = new Color(252,147,3);
   
   }else if(sala.equals("501")){
                foreground = new Color(255,255,255);
                background = new Color(1,1,1);
                table.setToolTipText("Sindicato fechado!");
   
   }else if(sala.equals("502")){
                foreground = new Color(255,255,255);
                background = new Color(204,0,0);
         
   }else if(nome.equals("Tina")){
                foreground = new Color(255,255,255);
                background = new Color(235,181,125);
   }else{
                renderer.setForeground(renderer.getForeground());
                renderer.setBackground(renderer.getBackground());
   }
          
                  
    renderer.setForeground(foreground);
    renderer.setBackground(background);
    return renderer; 
  }
}