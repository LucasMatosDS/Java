/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author lucas
 */
public class ClienteVO {
        
    private long id_visitante;
    private String data;
    private String nome;
    private String doc;
    private String h_entrada;
    private String h_saida;
    private int sala;
    private String observacao;

    public ClienteVO() {
    
    }

    public long getId_visitante() {
        return id_visitante;
    }

    public void setId_visitante(long id_visitante) {
        this.id_visitante = id_visitante;
    }
    
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }
    
    public String getH_entrada() {
        return h_entrada;
    }

    public void setH_entrada(String h_entrada) {
        this.h_entrada = h_entrada;
    }

    public String getH_saida() {
        return h_saida;
    }

    public void setH_saida(String h_saida) {
        this.h_saida = h_saida;
    }

    public int getSala() {
        return sala;
    }

    public void setSala(int sala) {
        this.sala = sala;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public String toString() {
        return "Id:"+ id_visitante +
               "Data"+ nome +
               "Nome:"+ nome +
               "Documento" + doc +
               "H_entrada:" + h_entrada +
               "H_saida:" + h_saida +
               "Sala:" + sala +
               "Observação:" + observacao;
    }

    
    
}
