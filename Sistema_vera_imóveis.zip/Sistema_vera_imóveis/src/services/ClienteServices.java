/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.ClienteDAO;
import dao.DAOFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import model.ClienteVO;

/**
 *
 * @author lucas
 */
public class ClienteServices {
    
   public void cadastrarCliente(ClienteVO cVO) throws SQLException {
        ClienteDAO cDAO = DAOFactory.getClienteDAO();
        cDAO.cadastrarCliente(cVO);
    }//fecha método cadastrar cliente
    
    
   public ArrayList<ClienteVO> buscarCliente() throws SQLException {
        ClienteDAO cDAO = DAOFactory.getClienteDAO();
        return cDAO.buscarCliente();
    }//fecha método buscar cliente
   
   public void deletarProduto(long id_visitante) throws SQLException{
        ClienteDAO cDAO = DAOFactory.getClienteDAO();
        cDAO.deletar(id_visitante);
      }//fecha método deletar cliente
   
   public void deletarTodosOsRegistros(String sala) throws SQLException{
       ClienteDAO cDAO = DAOFactory.getClienteDAO();
       cDAO.deletarTodosOsRegistros(sala);
   }//fecha método deletar todos os registros
   
   public void alterarHoraSaida(ClienteVO cVO) throws SQLException {
        ClienteDAO cDAO = DAOFactory.getClienteDAO();
        cDAO.alterar(cVO);
    }//fecha método alterar cliente
    
     
    public ArrayList<ClienteVO> filtrar(String query) throws SQLException{
        ClienteDAO cDAO = DAOFactory.getClienteDAO();
        return cDAO.filtrar(query);
    }//fecha método filtrar cliente
}
